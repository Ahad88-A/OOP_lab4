
class task_1{

	public static void main (String [] args){

		int [] nums ={5,3,8,6,2};
		int max =0;
		int second_max = -1;

		for (int i=0; i<nums.length; i++){
			if (nums[i]>max)
				max = nums[i];

			for (int j=0; j<nums.length; j++){
				if (nums[j]>second_max && nums[j] < max){
					second_max=nums[j];
				}
			}
		}

System.out.println(max);
System.out.println(second_max);

}
}










