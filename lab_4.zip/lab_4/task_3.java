

class task_3{

	public static void main (String [] args){

		int nums = 15;

		for (int i=1; i<=nums; i++){
			if (i % 3 == 0){
				System.out.println("Fizz");
			}
			else if (i % 5 == 0){
				System.out.println("Buzz");
			}
			else if (i % 3 == 0 && i % 5 == 0){
				System.out.println("FizzBuzz");
			}
		}	
		}
	}